try:
    from StringIO import StringIO as BytesIO
except ImportError:
    from io import BytesIO
